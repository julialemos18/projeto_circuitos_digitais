-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "06/26/2026 10:53:00"

-- 
-- Device: Altera EP4CGX15BF14C6 Package FBGA169
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIV;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIV.CYCLONEIV_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	NeanderPC IS
    PORT (
	Q : OUT std_logic_vector(7 DOWNTO 0);
	Cg_PC : IN std_logic;
	HLT : IN std_logic;
	Inc_PC : IN std_logic;
	CK : IN std_logic;
	RST : IN std_logic;
	D : IN std_logic_vector(7 DOWNTO 0)
	);
END NeanderPC;

-- Design Ports Information
-- Q[7]	=>  Location: PIN_D10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Q[6]	=>  Location: PIN_E13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Q[5]	=>  Location: PIN_F9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Q[4]	=>  Location: PIN_C11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Q[3]	=>  Location: PIN_B8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Q[2]	=>  Location: PIN_D13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Q[1]	=>  Location: PIN_A13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Q[0]	=>  Location: PIN_C13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- CK	=>  Location: PIN_J7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Inc_PC	=>  Location: PIN_F13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D[7]	=>  Location: PIN_F12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RST	=>  Location: PIN_J6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Cg_PC	=>  Location: PIN_D12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- HLT	=>  Location: PIN_D11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D[6]	=>  Location: PIN_F11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D[5]	=>  Location: PIN_F10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D[4]	=>  Location: PIN_B11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D[3]	=>  Location: PIN_B10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D[2]	=>  Location: PIN_E10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D[1]	=>  Location: PIN_B13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D[0]	=>  Location: PIN_C12,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF NeanderPC IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_Q : std_logic_vector(7 DOWNTO 0);
SIGNAL ww_Cg_PC : std_logic;
SIGNAL ww_HLT : std_logic;
SIGNAL ww_Inc_PC : std_logic;
SIGNAL ww_CK : std_logic;
SIGNAL ww_RST : std_logic;
SIGNAL ww_D : std_logic_vector(7 DOWNTO 0);
SIGNAL \RST~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \CK~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \Q[7]~output_o\ : std_logic;
SIGNAL \Q[6]~output_o\ : std_logic;
SIGNAL \Q[5]~output_o\ : std_logic;
SIGNAL \Q[4]~output_o\ : std_logic;
SIGNAL \Q[3]~output_o\ : std_logic;
SIGNAL \Q[2]~output_o\ : std_logic;
SIGNAL \Q[1]~output_o\ : std_logic;
SIGNAL \Q[0]~output_o\ : std_logic;
SIGNAL \CK~input_o\ : std_logic;
SIGNAL \CK~inputclkctrl_outclk\ : std_logic;
SIGNAL \Inc_PC~input_o\ : std_logic;
SIGNAL \D[0]~input_o\ : std_logic;
SIGNAL \Cg_PC~input_o\ : std_logic;
SIGNAL \inst|inst30|inst4~0_combout\ : std_logic;
SIGNAL \RST~input_o\ : std_logic;
SIGNAL \RST~inputclkctrl_outclk\ : std_logic;
SIGNAL \HLT~input_o\ : std_logic;
SIGNAL \inst|inst8~q\ : std_logic;
SIGNAL \inst|inst31|inst4~0_combout\ : std_logic;
SIGNAL \inst|inst9~0_combout\ : std_logic;
SIGNAL \D[1]~input_o\ : std_logic;
SIGNAL \inst|inst31|inst4~1_combout\ : std_logic;
SIGNAL \inst|inst9~q\ : std_logic;
SIGNAL \inst|inst32|inst4~0_combout\ : std_logic;
SIGNAL \inst|inst10~0_combout\ : std_logic;
SIGNAL \D[2]~input_o\ : std_logic;
SIGNAL \inst|inst32|inst4~1_combout\ : std_logic;
SIGNAL \inst|inst10~q\ : std_logic;
SIGNAL \inst|inst33|inst4~0_combout\ : std_logic;
SIGNAL \inst|inst11~0_combout\ : std_logic;
SIGNAL \D[3]~input_o\ : std_logic;
SIGNAL \inst|inst33|inst4~1_combout\ : std_logic;
SIGNAL \inst|inst11~q\ : std_logic;
SIGNAL \inst|inst54~combout\ : std_logic;
SIGNAL \inst|inst34|inst4~0_combout\ : std_logic;
SIGNAL \inst|inst12~0_combout\ : std_logic;
SIGNAL \D[4]~input_o\ : std_logic;
SIGNAL \inst|inst34|inst4~1_combout\ : std_logic;
SIGNAL \inst|inst12~q\ : std_logic;
SIGNAL \inst|inst35|inst4~0_combout\ : std_logic;
SIGNAL \inst|inst13~0_combout\ : std_logic;
SIGNAL \D[5]~input_o\ : std_logic;
SIGNAL \inst|inst35|inst4~1_combout\ : std_logic;
SIGNAL \inst|inst13~q\ : std_logic;
SIGNAL \inst|inst38|inst4~0_combout\ : std_logic;
SIGNAL \inst|inst14~0_combout\ : std_logic;
SIGNAL \D[6]~input_o\ : std_logic;
SIGNAL \inst|inst38|inst4~1_combout\ : std_logic;
SIGNAL \inst|inst14~q\ : std_logic;
SIGNAL \inst|inst45|inst4~0_combout\ : std_logic;
SIGNAL \inst|inst45|inst4~1_combout\ : std_logic;
SIGNAL \inst|inst41~0_combout\ : std_logic;
SIGNAL \D[7]~input_o\ : std_logic;
SIGNAL \inst|inst45|inst4~2_combout\ : std_logic;
SIGNAL \inst|inst41~q\ : std_logic;
SIGNAL \ALT_INV_RST~inputclkctrl_outclk\ : std_logic;
SIGNAL \ALT_INV_HLT~input_o\ : std_logic;

BEGIN

Q <= ww_Q;
ww_Cg_PC <= Cg_PC;
ww_HLT <= HLT;
ww_Inc_PC <= Inc_PC;
ww_CK <= CK;
ww_RST <= RST;
ww_D <= D;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\RST~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \RST~input_o\);

\CK~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \CK~input_o\);
\ALT_INV_RST~inputclkctrl_outclk\ <= NOT \RST~inputclkctrl_outclk\;
\ALT_INV_HLT~input_o\ <= NOT \HLT~input_o\;

-- Location: IOOBUF_X33_Y27_N9
\Q[7]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|inst41~q\,
	devoe => ww_devoe,
	o => \Q[7]~output_o\);

-- Location: IOOBUF_X33_Y25_N9
\Q[6]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|inst14~q\,
	devoe => ww_devoe,
	o => \Q[6]~output_o\);

-- Location: IOOBUF_X33_Y25_N2
\Q[5]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|inst13~q\,
	devoe => ww_devoe,
	o => \Q[5]~output_o\);

-- Location: IOOBUF_X31_Y31_N2
\Q[4]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|inst12~q\,
	devoe => ww_devoe,
	o => \Q[4]~output_o\);

-- Location: IOOBUF_X22_Y31_N2
\Q[3]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|inst11~q\,
	devoe => ww_devoe,
	o => \Q[3]~output_o\);

-- Location: IOOBUF_X29_Y31_N9
\Q[2]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|inst10~q\,
	devoe => ww_devoe,
	o => \Q[2]~output_o\);

-- Location: IOOBUF_X26_Y31_N2
\Q[1]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|inst9~q\,
	devoe => ww_devoe,
	o => \Q[1]~output_o\);

-- Location: IOOBUF_X29_Y31_N2
\Q[0]~output\ : cycloneiv_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|inst8~q\,
	devoe => ww_devoe,
	o => \Q[0]~output_o\);

-- Location: IOIBUF_X16_Y0_N15
\CK~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CK,
	o => \CK~input_o\);

-- Location: CLKCTRL_G17
\CK~inputclkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \CK~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \CK~inputclkctrl_outclk\);

-- Location: IOIBUF_X33_Y16_N8
\Inc_PC~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_Inc_PC,
	o => \Inc_PC~input_o\);

-- Location: IOIBUF_X31_Y31_N8
\D[0]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D(0),
	o => \D[0]~input_o\);

-- Location: IOIBUF_X33_Y28_N8
\Cg_PC~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_Cg_PC,
	o => \Cg_PC~input_o\);

-- Location: LCCOMB_X31_Y28_N26
\inst|inst30|inst4~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst30|inst4~0_combout\ = (\Cg_PC~input_o\ & ((\D[0]~input_o\) # ((\Inc_PC~input_o\)))) # (!\Cg_PC~input_o\ & ((\Inc_PC~input_o\ $ (\inst|inst8~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \D[0]~input_o\,
	datab => \Inc_PC~input_o\,
	datac => \inst|inst8~q\,
	datad => \Cg_PC~input_o\,
	combout => \inst|inst30|inst4~0_combout\);

-- Location: IOIBUF_X16_Y0_N22
\RST~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_RST,
	o => \RST~input_o\);

-- Location: CLKCTRL_G19
\RST~inputclkctrl\ : cycloneiv_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \RST~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \RST~inputclkctrl_outclk\);

-- Location: IOIBUF_X33_Y28_N1
\HLT~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_HLT,
	o => \HLT~input_o\);

-- Location: FF_X31_Y28_N27
\inst|inst8\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \inst|inst30|inst4~0_combout\,
	clrn => \ALT_INV_RST~inputclkctrl_outclk\,
	ena => \ALT_INV_HLT~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst8~q\);

-- Location: LCCOMB_X31_Y28_N10
\inst|inst31|inst4~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst31|inst4~0_combout\ = \inst|inst8~q\ $ (\inst|inst9~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst8~q\,
	datad => \inst|inst9~q\,
	combout => \inst|inst31|inst4~0_combout\);

-- Location: LCCOMB_X31_Y28_N24
\inst|inst9~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst9~0_combout\ = (\Inc_PC~input_o\ & ((\inst|inst31|inst4~0_combout\))) # (!\Inc_PC~input_o\ & (\inst|inst9~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \Inc_PC~input_o\,
	datac => \inst|inst9~q\,
	datad => \inst|inst31|inst4~0_combout\,
	combout => \inst|inst9~0_combout\);

-- Location: IOIBUF_X26_Y31_N8
\D[1]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D(1),
	o => \D[1]~input_o\);

-- Location: LCCOMB_X31_Y28_N8
\inst|inst31|inst4~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst31|inst4~1_combout\ = (\Inc_PC~input_o\) # (\D[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \Inc_PC~input_o\,
	datad => \D[1]~input_o\,
	combout => \inst|inst31|inst4~1_combout\);

-- Location: FF_X31_Y28_N25
\inst|inst9\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \inst|inst9~0_combout\,
	asdata => \inst|inst31|inst4~1_combout\,
	clrn => \ALT_INV_RST~inputclkctrl_outclk\,
	sload => \Cg_PC~input_o\,
	ena => \ALT_INV_HLT~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst9~q\);

-- Location: LCCOMB_X31_Y28_N28
\inst|inst32|inst4~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst32|inst4~0_combout\ = \inst|inst10~q\ $ (((\inst|inst8~q\ & \inst|inst9~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst10~q\,
	datac => \inst|inst8~q\,
	datad => \inst|inst9~q\,
	combout => \inst|inst32|inst4~0_combout\);

-- Location: LCCOMB_X31_Y28_N22
\inst|inst10~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst10~0_combout\ = (\Inc_PC~input_o\ & ((\inst|inst32|inst4~0_combout\))) # (!\Inc_PC~input_o\ & (\inst|inst10~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \Inc_PC~input_o\,
	datac => \inst|inst10~q\,
	datad => \inst|inst32|inst4~0_combout\,
	combout => \inst|inst10~0_combout\);

-- Location: IOIBUF_X33_Y27_N1
\D[2]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D(2),
	o => \D[2]~input_o\);

-- Location: LCCOMB_X32_Y28_N0
\inst|inst32|inst4~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst32|inst4~1_combout\ = (\Inc_PC~input_o\) # (\D[2]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \Inc_PC~input_o\,
	datad => \D[2]~input_o\,
	combout => \inst|inst32|inst4~1_combout\);

-- Location: FF_X31_Y28_N23
\inst|inst10\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \inst|inst10~0_combout\,
	asdata => \inst|inst32|inst4~1_combout\,
	clrn => \ALT_INV_RST~inputclkctrl_outclk\,
	sload => \Cg_PC~input_o\,
	ena => \ALT_INV_HLT~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst10~q\);

-- Location: LCCOMB_X31_Y28_N12
\inst|inst33|inst4~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst33|inst4~0_combout\ = \inst|inst11~q\ $ (((\inst|inst10~q\ & (\inst|inst9~q\ & \inst|inst8~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst10~q\,
	datab => \inst|inst9~q\,
	datac => \inst|inst8~q\,
	datad => \inst|inst11~q\,
	combout => \inst|inst33|inst4~0_combout\);

-- Location: LCCOMB_X31_Y28_N4
\inst|inst11~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst11~0_combout\ = (\Inc_PC~input_o\ & ((\inst|inst33|inst4~0_combout\))) # (!\Inc_PC~input_o\ & (\inst|inst11~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \Inc_PC~input_o\,
	datac => \inst|inst11~q\,
	datad => \inst|inst33|inst4~0_combout\,
	combout => \inst|inst11~0_combout\);

-- Location: IOIBUF_X24_Y31_N8
\D[3]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D(3),
	o => \D[3]~input_o\);

-- Location: LCCOMB_X31_Y28_N14
\inst|inst33|inst4~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst33|inst4~1_combout\ = (\Inc_PC~input_o\) # (\D[3]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \Inc_PC~input_o\,
	datad => \D[3]~input_o\,
	combout => \inst|inst33|inst4~1_combout\);

-- Location: FF_X31_Y28_N5
\inst|inst11\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \inst|inst11~0_combout\,
	asdata => \inst|inst33|inst4~1_combout\,
	clrn => \ALT_INV_RST~inputclkctrl_outclk\,
	sload => \Cg_PC~input_o\,
	ena => \ALT_INV_HLT~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst11~q\);

-- Location: LCCOMB_X31_Y28_N20
\inst|inst54\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst54~combout\ = (\inst|inst10~q\ & (\inst|inst11~q\ & (\inst|inst8~q\ & \inst|inst9~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst10~q\,
	datab => \inst|inst11~q\,
	datac => \inst|inst8~q\,
	datad => \inst|inst9~q\,
	combout => \inst|inst54~combout\);

-- Location: LCCOMB_X32_Y28_N6
\inst|inst34|inst4~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst34|inst4~0_combout\ = \inst|inst12~q\ $ (\inst|inst54~combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \inst|inst12~q\,
	datad => \inst|inst54~combout\,
	combout => \inst|inst34|inst4~0_combout\);

-- Location: LCCOMB_X32_Y28_N30
\inst|inst12~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst12~0_combout\ = (\Inc_PC~input_o\ & ((\inst|inst34|inst4~0_combout\))) # (!\Inc_PC~input_o\ & (\inst|inst12~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Inc_PC~input_o\,
	datac => \inst|inst12~q\,
	datad => \inst|inst34|inst4~0_combout\,
	combout => \inst|inst12~0_combout\);

-- Location: IOIBUF_X24_Y31_N1
\D[4]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D(4),
	o => \D[4]~input_o\);

-- Location: LCCOMB_X31_Y28_N6
\inst|inst34|inst4~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst34|inst4~1_combout\ = (\Inc_PC~input_o\) # (\D[4]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \Inc_PC~input_o\,
	datad => \D[4]~input_o\,
	combout => \inst|inst34|inst4~1_combout\);

-- Location: FF_X32_Y28_N31
\inst|inst12\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \inst|inst12~0_combout\,
	asdata => \inst|inst34|inst4~1_combout\,
	clrn => \ALT_INV_RST~inputclkctrl_outclk\,
	sload => \Cg_PC~input_o\,
	ena => \ALT_INV_HLT~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst12~q\);

-- Location: LCCOMB_X32_Y28_N18
\inst|inst35|inst4~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst35|inst4~0_combout\ = \inst|inst13~q\ $ (((\inst|inst12~q\ & \inst|inst54~combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \inst|inst13~q\,
	datac => \inst|inst12~q\,
	datad => \inst|inst54~combout\,
	combout => \inst|inst35|inst4~0_combout\);

-- Location: LCCOMB_X32_Y28_N16
\inst|inst13~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst13~0_combout\ = (\Inc_PC~input_o\ & ((\inst|inst35|inst4~0_combout\))) # (!\Inc_PC~input_o\ & (\inst|inst13~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Inc_PC~input_o\,
	datac => \inst|inst13~q\,
	datad => \inst|inst35|inst4~0_combout\,
	combout => \inst|inst13~0_combout\);

-- Location: IOIBUF_X33_Y24_N1
\D[5]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D(5),
	o => \D[5]~input_o\);

-- Location: LCCOMB_X32_Y28_N20
\inst|inst35|inst4~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst35|inst4~1_combout\ = (\Inc_PC~input_o\) # (\D[5]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \Inc_PC~input_o\,
	datad => \D[5]~input_o\,
	combout => \inst|inst35|inst4~1_combout\);

-- Location: FF_X32_Y28_N17
\inst|inst13\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \inst|inst13~0_combout\,
	asdata => \inst|inst35|inst4~1_combout\,
	clrn => \ALT_INV_RST~inputclkctrl_outclk\,
	sload => \Cg_PC~input_o\,
	ena => \ALT_INV_HLT~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst13~q\);

-- Location: LCCOMB_X32_Y28_N2
\inst|inst38|inst4~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst38|inst4~0_combout\ = \inst|inst14~q\ $ (((\inst|inst13~q\ & (\inst|inst12~q\ & \inst|inst54~combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst14~q\,
	datab => \inst|inst13~q\,
	datac => \inst|inst12~q\,
	datad => \inst|inst54~combout\,
	combout => \inst|inst38|inst4~0_combout\);

-- Location: LCCOMB_X32_Y28_N22
\inst|inst14~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst14~0_combout\ = (\Inc_PC~input_o\ & ((\inst|inst38|inst4~0_combout\))) # (!\Inc_PC~input_o\ & (\inst|inst14~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Inc_PC~input_o\,
	datac => \inst|inst14~q\,
	datad => \inst|inst38|inst4~0_combout\,
	combout => \inst|inst14~0_combout\);

-- Location: IOIBUF_X33_Y24_N8
\D[6]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D(6),
	o => \D[6]~input_o\);

-- Location: LCCOMB_X32_Y28_N8
\inst|inst38|inst4~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst38|inst4~1_combout\ = (\Inc_PC~input_o\) # (\D[6]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \Inc_PC~input_o\,
	datad => \D[6]~input_o\,
	combout => \inst|inst38|inst4~1_combout\);

-- Location: FF_X32_Y28_N23
\inst|inst14\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \inst|inst14~0_combout\,
	asdata => \inst|inst38|inst4~1_combout\,
	clrn => \ALT_INV_RST~inputclkctrl_outclk\,
	sload => \Cg_PC~input_o\,
	ena => \ALT_INV_HLT~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst14~q\);

-- Location: LCCOMB_X32_Y28_N4
\inst|inst45|inst4~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst45|inst4~0_combout\ = (!\inst|inst13~q\) # (!\inst|inst12~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \inst|inst12~q\,
	datad => \inst|inst13~q\,
	combout => \inst|inst45|inst4~0_combout\);

-- Location: LCCOMB_X32_Y28_N10
\inst|inst45|inst4~1\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst45|inst4~1_combout\ = \inst|inst41~q\ $ (((\inst|inst14~q\ & (!\inst|inst45|inst4~0_combout\ & \inst|inst54~combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100011011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \inst|inst14~q\,
	datab => \inst|inst41~q\,
	datac => \inst|inst45|inst4~0_combout\,
	datad => \inst|inst54~combout\,
	combout => \inst|inst45|inst4~1_combout\);

-- Location: LCCOMB_X32_Y28_N12
\inst|inst41~0\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst41~0_combout\ = (\Inc_PC~input_o\ & ((\inst|inst45|inst4~1_combout\))) # (!\Inc_PC~input_o\ & (\inst|inst41~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Inc_PC~input_o\,
	datac => \inst|inst41~q\,
	datad => \inst|inst45|inst4~1_combout\,
	combout => \inst|inst41~0_combout\);

-- Location: IOIBUF_X33_Y16_N1
\D[7]~input\ : cycloneiv_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D(7),
	o => \D[7]~input_o\);

-- Location: LCCOMB_X32_Y28_N28
\inst|inst45|inst4~2\ : cycloneiv_lcell_comb
-- Equation(s):
-- \inst|inst45|inst4~2_combout\ = (\D[7]~input_o\) # (\Inc_PC~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \D[7]~input_o\,
	datac => \Inc_PC~input_o\,
	combout => \inst|inst45|inst4~2_combout\);

-- Location: FF_X32_Y28_N13
\inst|inst41\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CK~inputclkctrl_outclk\,
	d => \inst|inst41~0_combout\,
	asdata => \inst|inst45|inst4~2_combout\,
	clrn => \ALT_INV_RST~inputclkctrl_outclk\,
	sload => \Cg_PC~input_o\,
	ena => \ALT_INV_HLT~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \inst|inst41~q\);

ww_Q(7) <= \Q[7]~output_o\;

ww_Q(6) <= \Q[6]~output_o\;

ww_Q(5) <= \Q[5]~output_o\;

ww_Q(4) <= \Q[4]~output_o\;

ww_Q(3) <= \Q[3]~output_o\;

ww_Q(2) <= \Q[2]~output_o\;

ww_Q(1) <= \Q[1]~output_o\;

ww_Q(0) <= \Q[0]~output_o\;
END structure;


