library verilog;
use verilog.vl_types.all;
entity Neander is
    port(
        N               : out    vl_logic;
        Z               : out    vl_logic;
        CK              : in     vl_logic;
        RST             : in     vl_logic;
        RI              : out    vl_logic_vector(7 downto 0);
        RDM             : out    vl_logic_vector(7 downto 0);
        MEM             : out    vl_logic_vector(7 downto 0);
        \REM\           : out    vl_logic_vector(7 downto 0);
        MUX             : out    vl_logic_vector(7 downto 0);
        PC              : out    vl_logic_vector(7 downto 0);
        ULA             : out    vl_logic_vector(7 downto 0);
        AC              : out    vl_logic_vector(7 downto 0);
        T               : out    vl_logic_vector(7 downto 0);
        tempo           : out    vl_logic_vector(2 downto 0);
        X               : out    vl_logic_vector(15 downto 0)
    );
end Neander;
