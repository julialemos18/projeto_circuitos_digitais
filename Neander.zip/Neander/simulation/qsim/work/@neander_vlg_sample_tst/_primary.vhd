library verilog;
use verilog.vl_types.all;
entity Neander_vlg_sample_tst is
    port(
        CK              : in     vl_logic;
        RST             : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end Neander_vlg_sample_tst;
