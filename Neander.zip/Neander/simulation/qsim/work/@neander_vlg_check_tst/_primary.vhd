library verilog;
use verilog.vl_types.all;
entity Neander_vlg_check_tst is
    port(
        AC              : in     vl_logic_vector(7 downto 0);
        MEM             : in     vl_logic_vector(7 downto 0);
        MUX             : in     vl_logic_vector(7 downto 0);
        N               : in     vl_logic;
        PC              : in     vl_logic_vector(7 downto 0);
        RDM             : in     vl_logic_vector(7 downto 0);
        \REM\           : in     vl_logic_vector(7 downto 0);
        RI              : in     vl_logic_vector(7 downto 0);
        T               : in     vl_logic_vector(7 downto 0);
        tempo           : in     vl_logic_vector(2 downto 0);
        ULA             : in     vl_logic_vector(7 downto 0);
        X               : in     vl_logic_vector(15 downto 0);
        Z               : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end Neander_vlg_check_tst;
